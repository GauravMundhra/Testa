import sys
#hello
def helloworld(out):
	out.write('hello Aman')
	out.write('hello Apar')
	print("Hello World")

print("Hello Aman")
print("Hello Apar")
print("Hello Shashwat")

