import sys
#hello
def helloworld(out):
	out.write('hello Gaurav')
	out.write('hello ')
	print("Hello World")

print("Hello 1")
print("Hello 2")
print("Hello 3")

